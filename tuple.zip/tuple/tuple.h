#ifndef TUPLE_H_
#define TUPLE_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include "../vector/vector.h"
#include "../string/string.h"
#include "../stack/stack.h"
#include "../array/array.h"
#include "../span/span.h"
#include "../map/map.h"
#include "../list/list.h"
#include "../forward_list/forward_list.h"

typedef enum {
    TUPLE_TYPE_INT,
    TUPLE_TYPE_CHAR,
    TUPLE_TYPE_FLOAT,
    TUPLE_TYPE_DOUBLE,
    TUPLE_TYPE_CHAR_STRING,
    TUPLE_TYPE_POINTER,
    TUPLE_TYPE_UINT16,
    TUPLE_TYPE_UINT8,
    TUPLE_TYPE_UINT32,
    TUPLE_TYPE_UINT64,
    TUPLE_TYPE_INT8,
    TUPLE_TYPE_INT16,
    TUPLE_TYPE_INT32,
    TUPLE_TYPE_INT64,
    TUPLE_TYPE_VECTOR,
    TUPLE_TYPE_STRING,
    TUPLE_TYPE_STACK,
    TUPLE_TYPE_ARRAY,
    TUPLE_TYPE_SPAN,
    TUPLE_TYPE_LIST,
    TUPLE_TYPE_FORWARD_LIST,
    TUPLE_TYPE_MAP,
    TUPLE_TYPE_UNKNOWN,
    // ... other types as needed
} TupleType;

typedef struct {
    TupleType type;
    union {
        int intValue;
        char charValue;
        float floatValue;
        double doubleValue;
        char* charStringValue;
        void* pointerValue;
        uint16_t uint16Value;
        uint8_t uint8Value;
        uint32_t uint32Value;
        uint64_t uint64Value;
        int8_t int8Value;
        int16_t int16Value;
        int32_t int32Value;
        int64_t int64Value;
        Vector* vectorValue;
        String* stringValue;
        Stack* stackValue;
        Array* ArrayValue;
        Span* spanValue;
        List* listValue;
        ForwardList* forwardListValue;
        Map* mapValue;
        // ... other types as needed
    } data;
} TupleElement;

typedef struct {
    TupleElement* elements;
    size_t size;
} Tuple;

// Creation and deallocation
Tuple* tuple_create(size_t size, ...);
void tuple_deallocate(Tuple* tuple);

// Setters
bool tuple_set_int(Tuple* tuple, size_t index, int value);
bool tuple_set_char(Tuple* tuple, size_t index, char value);
bool tuple_set_float(Tuple* tuple, size_t index, float value);
bool tuple_set_double(Tuple* tuple, size_t index, double value);
bool tuple_set_char_string(Tuple* tuple, size_t index, const char* value);
bool tuple_set_pointer(Tuple* tuple, size_t index, void* value);
bool tuple_set_uint16(Tuple* tuple, size_t index, uint16_t value);
bool tuple_set_uint8(Tuple* tuple, size_t index, uint8_t value);
bool tuple_set_uint32(Tuple* tuple, size_t index, uint32_t value);
bool tuple_set_uint64(Tuple* tuple, size_t index, uint64_t value);
bool tuple_set_int8(Tuple* tuple, size_t index, int8_t value);
bool tuple_set_int16(Tuple* tuple, size_t index, int16_t value);
bool tuple_set_int32(Tuple* tuple, size_t index, int32_t value);
bool tuple_set_int64(Tuple* tuple, size_t index, int64_t value);
bool tuple_set_vector(Tuple* tuple, size_t index, Vector* value);
bool tuple_set_string(Tuple* tuple, size_t index, String* value);
bool tuple_set_array(Tuple* tuple, size_t index, Array* value);
bool tuple_set_stack(Tuple* tuple, size_t index, Stack* value);
bool tuple_set_span(Tuple* tuple, size_t index, Span* value);
bool tuple_set_list(Tuple* tuple, size_t index, List* value);
bool tuple_set_forward_list(Tuple* tuple, size_t index, ForwardList* value);
bool tuple_set_map(Tuple* tuple, size_t index, Map* value);
// Getters
bool tuple_get_int(const Tuple* tuple, size_t index, int* outValue);
bool tuple_get_char(const Tuple* tuple, size_t index, char* outValue);
bool tuple_get_float(const Tuple* tuple, size_t index, float* outValue);
bool tuple_get_double(const Tuple* tuple, size_t index, double* outValue);
bool tuple_get_char_string(const Tuple* tuple, size_t index, char** outValue);
bool tuple_get_pointer(const Tuple* tuple, size_t index, void** outValue);
bool tuple_get_uint16(const Tuple* tuple, size_t index, uint16_t* outValue);
bool tuple_get_uint8(const Tuple* tuple, size_t index, uint8_t* outValue);
bool tuple_get_uint32(const Tuple* tuple, size_t index, uint32_t* outValue);
bool tuple_get_uint64(const Tuple* tuple, size_t index, uint64_t* outValue);
bool tuple_get_int8(const Tuple* tuple, size_t index, int8_t* outValue);
bool tuple_get_int16(const Tuple* tuple, size_t index, int16_t* outValue);
bool tuple_get_int32(const Tuple* tuple, size_t index, int32_t* outValue);
bool tuple_get_int64(const Tuple* tuple, size_t index, int64_t* outValue);
bool tuple_get_vector(const Tuple* tuple, size_t index, Vector** outValue);
bool tuple_get_string(const Tuple* tuple, size_t index, String** outValue);
bool tuple_get_array(const Tuple* tuple, size_t index, Array** outValue);
bool tuple_get_stack(const Tuple* tuple, size_t index, Stack** outValue);
bool tuple_get_span(const Tuple* tuple, size_t index, Span** outValue);
bool tuple_get_list(const Tuple* tuple, size_t index, List** outValue);
bool tuple_get_forward_list(const Tuple* tuple, size_t index, ForwardList** outValue);
bool tuple_get_map(const Tuple* tuple, size_t index, Map** outValue);
// ... other getter functions for different types

#endif // TUPLE_H_
