#include "tuple.h"
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "../algorithm/algorithm.h"

Tuple* tuple_create(size_t size, ...) {
    Tuple* tuple = (Tuple*)malloc(sizeof(Tuple));
    if (!tuple) return NULL;

    tuple->size = size;
    tuple->elements = (TupleElement*)malloc(size * sizeof(TupleElement));
    if (!tuple->elements) {
        free(tuple);
        return NULL;
    }

    va_list args;
    va_start(args, size);

    for (size_t i = 0; i < size; i++) {
        TupleType type = va_arg(args, TupleType);
        tuple->elements[i].type = type;

        switch (type) {
            case TUPLE_TYPE_INT: 
                tuple->elements[i].data.intValue = 0; 
                break;
            case TUPLE_TYPE_CHAR: 
                tuple->elements[i].data.charValue = 0; 
                break;
            case TUPLE_TYPE_FLOAT: 
                tuple->elements[i].data.floatValue = 0.0f; 
                break;
            case TUPLE_TYPE_DOUBLE: 
                tuple->elements[i].data.doubleValue = 0.0; 
                break;
            case TUPLE_TYPE_CHAR_STRING:
                tuple->elements[i].data.charStringValue = NULL;
                break;
            case TUPLE_TYPE_POINTER:
                tuple->elements[i].data.pointerValue = NULL;
                break;
            case TUPLE_TYPE_UINT16:
                tuple->elements[i].data.uint16Value = 0;
                break;
            case TUPLE_TYPE_UINT8:
                tuple->elements[i].data.uint8Value = 0;
                break;
            case TUPLE_TYPE_UINT32:
                tuple->elements[i].data.uint32Value = 0;
                break;
            case TUPLE_TYPE_UINT64:
                tuple->elements[i].data.uint64Value = 0;
                break;
            case TUPLE_TYPE_INT8:
                tuple->elements[i].data.int8Value = 0;
                break;
            case TUPLE_TYPE_INT16:
                tuple->elements[i].data.int16Value = 0;
                break;
            case TUPLE_TYPE_INT32:
                tuple->elements[i].data.int32Value = 0;
                break;
            case TUPLE_TYPE_INT64:
                tuple->elements[i].data.int64Value = 0;
                break;
            case TUPLE_TYPE_VECTOR:
                tuple->elements[i].data.vectorValue = NULL;
                break;
            case TUPLE_TYPE_STRING:
                tuple->elements[i].data.stringValue = NULL;
                break;
            case TUPLE_TYPE_STACK:
                tuple->elements[i].data.stackValue = NULL;
                break;
            case TUPLE_TYPE_ARRAY:
                tuple->elements[i].data.ArrayValue = NULL;
                break;
            case TUPLE_TYPE_SPAN:
                tuple->elements[i].data.spanValue = NULL;
                break;
            case TUPLE_TYPE_LIST:
                tuple->elements[i].data.listValue = NULL;
                break;
            case TUPLE_TYPE_FORWARD_LIST:
                tuple->elements[i].data.forwardListValue = NULL;
                break;
            case TUPLE_TYPE_MAP:
                tuple->elements[i].data.mapValue = NULL;
                break;
            default:
                // Set to zero for unknown types
                memset(&(tuple->elements[i].data), 0, sizeof(tuple->elements[i].data)); 
                break;
        }
    }

    va_end(args);
    return tuple;
}

void tuple_deallocate(Tuple* tuple) {
    if (!tuple) {
        return;
    }

    // Free memory allocated for each element based on its type
    for (size_t i = 0; i < tuple->size; i++) {
        switch (tuple->elements[i].type) {
            case TUPLE_TYPE_CHAR_STRING:
                free(tuple->elements[i].data.charStringValue);
                break;
            case TUPLE_TYPE_STRING:
                string_deallocate(tuple->elements[i].data.stringValue);
                break;
            case TUPLE_TYPE_VECTOR:
                vector_deallocate(tuple->elements[i].data.vectorValue);
                break;
            case TUPLE_TYPE_STACK:
                stack_deallocate(tuple->elements[i].data.stackValue);
                break;
            case TUPLE_TYPE_ARRAY:
                array_deallocate(tuple->elements[i].data.ArrayValue);
                break;
            case TUPLE_TYPE_SPAN:
                span_destroy(tuple->elements[i].data.spanValue);
                break;
            case TUPLE_TYPE_LIST:
                list_deallocate(tuple->elements[i].data.listValue);
                break;
            case TUPLE_TYPE_FORWARD_LIST:
                forward_list_deallocate(tuple->elements[i].data.forwardListValue);
                break;
            case TUPLE_TYPE_MAP:
                map_deallocate(tuple->elements[i].data.mapValue);
                break;
            // No action required for other types
            default:
                break;
        }
    }

    free(tuple->elements);
    free(tuple);
}

static bool generic_setter(Tuple* tuple, TupleType type, void* value, size_t index) {
    if (!tuple || index >= tuple->size) {
        return false;
    }

    tuple->elements[index].type = type;

    switch (type) {
        case TUPLE_TYPE_INT:
            tuple->elements[index].data.intValue = *((int*)value);
            break;
        case TUPLE_TYPE_CHAR:
            tuple->elements[index].data.charValue = *((char*)value);
            break;
        case TUPLE_TYPE_FLOAT:
            tuple->elements[index].data.floatValue = *((float*)value);
            break;
        case TUPLE_TYPE_DOUBLE:
            tuple->elements[index].data.doubleValue = *((double*)value);
            break;
        case TUPLE_TYPE_POINTER:
            tuple->elements[index].data.pointerValue = value;
            break;
        case TUPLE_TYPE_UINT16:
            tuple->elements[index].data.uint16Value = *((uint16_t*)value);
            break;
        case TUPLE_TYPE_UINT8:
            tuple->elements[index].data.uint8Value = *((uint8_t*)value);
            break;
        case TUPLE_TYPE_UINT32:
            tuple->elements[index].data.uint32Value = *((uint32_t*)value);
            break;
        case TUPLE_TYPE_UINT64:
            tuple->elements[index].data.uint64Value = *((uint64_t*)value);
            break;
        case TUPLE_TYPE_VECTOR:
            tuple->elements[index].data.vectorValue = (Vector*)value;
            break;
        case TUPLE_TYPE_STRING:
            tuple->elements[index].data.stringValue = (String*)value;
            break;
        // Add cases for other data types as needed
        default:
            // Handle unknown types
            memset(&(tuple->elements[index].data), 0, sizeof(tuple->elements[index].data));
            break;
    }

    return true;
}

static bool generic_getter(const Tuple* tuple, TupleType type, size_t index, void** outValue) {
    if (!tuple || index >= tuple->size || tuple->elements[index].type != type || !outValue) {
        return false;
    }

    switch (type) {
        case TUPLE_TYPE_INT:
            *((int*)outValue) = tuple->elements[index].data.intValue;
            break;
        case TUPLE_TYPE_CHAR:
            *((char*)outValue) = tuple->elements[index].data.charValue;
            break;
        case TUPLE_TYPE_FLOAT:
            *((float*)outValue) = tuple->elements[index].data.floatValue;
            break;
        case TUPLE_TYPE_DOUBLE:
            *((double*)outValue) = tuple->elements[index].data.doubleValue;
            break;
        case TUPLE_TYPE_POINTER:
            *((void**)outValue) = tuple->elements[index].data.pointerValue;
            break;
        case TUPLE_TYPE_UINT16:
            *((uint16_t*)outValue) = tuple->elements[index].data.uint16Value;
            break;
        case TUPLE_TYPE_UINT8:
            *((uint8_t*)outValue) = tuple->elements[index].data.uint8Value;
            break;
        case TUPLE_TYPE_UINT32:
            *((uint32_t*)outValue) = tuple->elements[index].data.uint32Value;
            break;
        case TUPLE_TYPE_UINT64:
            *((uint64_t*)outValue) = tuple->elements[index].data.uint64Value;
            break;
        case TUPLE_TYPE_INT8:
            *((int8_t*)outValue) = tuple->elements[index].data.int8Value;
            break;
        case TUPLE_TYPE_INT16:
            *((int16_t*)outValue) = tuple->elements[index].data.int16Value;
            break;
        case TUPLE_TYPE_INT32:
            *((int32_t*)outValue) = tuple->elements[index].data.int32Value;
            break;
        case TUPLE_TYPE_INT64:
            *((int64_t*)outValue) = tuple->elements[index].data.int64Value;
            break;
        case TUPLE_TYPE_VECTOR:
            *((Vector**)outValue) = tuple->elements[index].data.vectorValue;
            break;
        case TUPLE_TYPE_STRING:
            *((String**)outValue) = tuple->elements[index].data.stringValue;
            break;
        // Add cases for other data types as needed
        default:
            *outValue = NULL; // Unknown types, set to NULL
            break;
    }
    return true;
}

bool tuple_set_int(Tuple* tuple, size_t index, int value) {
    return generic_setter(tuple, TUPLE_TYPE_INT, &value, index);
}

bool tuple_set_char(Tuple* tuple, size_t index, char value) {
    return generic_setter(tuple, TUPLE_TYPE_CHAR, &value, index);
}

bool tuple_set_float(Tuple* tuple, size_t index, float value) {
    return generic_setter(tuple, TUPLE_TYPE_FLOAT, &value, index);
}

bool tuple_set_double(Tuple* tuple, size_t index, double value) {
    return generic_setter(tuple, TUPLE_TYPE_DOUBLE, &value, index);
}

bool tuple_set_char_string(Tuple* tuple, size_t index, const char* value) {
    if (!tuple || index >= tuple->size || !value) {
        return false;
    }
    // Free any existing string at this index
    if (tuple->elements[index].type == TUPLE_TYPE_CHAR_STRING) {
        free(tuple->elements[index].data.charStringValue);
    }

    tuple->elements[index].type = TUPLE_TYPE_CHAR_STRING;
    tuple->elements[index].data.charStringValue = string_strdup(value); // Duplicate the string

    return tuple->elements[index].data.charStringValue != NULL;
}

bool tuple_set_pointer(Tuple* tuple, size_t index, void* value) {
    return generic_setter(tuple, TUPLE_TYPE_POINTER, value, index);
}

bool tuple_set_uint16(Tuple* tuple, size_t index, uint16_t value) {
    return generic_setter(tuple, TUPLE_TYPE_UINT16, &value, index);
}

bool tuple_set_uint8(Tuple* tuple, size_t index, uint8_t value) {
    return generic_setter(tuple, TUPLE_TYPE_UINT8, &value, index);
}

bool tuple_set_uint32(Tuple* tuple, size_t index, uint32_t value) {
    return generic_setter(tuple, TUPLE_TYPE_UINT32, &value, index);
}

bool tuple_set_uint64(Tuple* tuple, size_t index, uint64_t value) {
    return generic_setter(tuple, TUPLE_TYPE_UINT64, &value, index);
}

bool tuple_set_int8(Tuple* tuple, size_t index, int8_t value) {
    return generic_setter(tuple, TUPLE_TYPE_INT8, &value, index);
}

bool tuple_set_int16(Tuple* tuple, size_t index, int16_t value) {
    return generic_setter(tuple, TUPLE_TYPE_INT16, &value, index);
}

bool tuple_set_int32(Tuple* tuple, size_t index, int32_t value) {
    return generic_setter(tuple, TUPLE_TYPE_INT32, &value, index);
}

bool tuple_set_int64(Tuple* tuple, size_t index, int64_t value) {
    return generic_setter(tuple, TUPLE_TYPE_INT64, &value, index);
}

bool tuple_set_vector(Tuple* tuple, size_t index, Vector* value) {
    return generic_setter(tuple, TUPLE_TYPE_VECTOR, value, index);
}

bool tuple_set_string(Tuple* tuple, size_t index, String* value) {
    return generic_setter(tuple, TUPLE_TYPE_STRING, value, index);
}

bool tuple_get_int(const Tuple* tuple, size_t index, int* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_INT, index, (void**)outValue);
}

bool tuple_get_char(const Tuple* tuple, size_t index, char* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_CHAR, index, (void**)outValue);
}

bool tuple_get_float(const Tuple* tuple, size_t index, float* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_FLOAT, index, (void**)outValue);
}

bool tuple_get_double(const Tuple* tuple, size_t index, double* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_DOUBLE, index, (void**)outValue);
}

bool tuple_get_char_string(const Tuple* tuple, size_t index, char** outValue) {
    if (!tuple || index >= tuple->size || tuple->elements[index].type != TUPLE_TYPE_CHAR_STRING || !outValue) {
        return false;
    }

    *outValue = tuple->elements[index].data.charStringValue;

    return true;
}

bool tuple_get_pointer(const Tuple* tuple, size_t index, void** outValue) {
    return generic_getter(tuple, TUPLE_TYPE_POINTER, index, (void**)outValue);
}

bool tuple_get_uint16(const Tuple* tuple, size_t index, uint16_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_UINT16, index, (void**)outValue);
}

bool tuple_get_uint8(const Tuple* tuple, size_t index, uint8_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_UINT8, index, (void**)outValue);
}

bool tuple_get_uint32(const Tuple* tuple, size_t index, uint32_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_UINT32, index, (void**)outValue);
}

bool tuple_get_int8(const Tuple* tuple, size_t index, int8_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_INT8, index, (void**)outValue);
}

bool tuple_get_int16(const Tuple* tuple, size_t index, int16_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_INT16, index, (void**)outValue);
}

bool tuple_get_int32(const Tuple* tuple, size_t index, int32_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_INT32, index, (void**)outValue);
}

bool tuple_get_int64(const Tuple* tuple, size_t index, int64_t* outValue) {
    return generic_getter(tuple, TUPLE_TYPE_INT64, index, (void**)outValue);
}

bool tuple_get_vector(const Tuple* tuple, size_t index, Vector** outValue) {
    return generic_getter(tuple, TUPLE_TYPE_VECTOR, index, (void**)outValue);
}

bool tuple_get_string(const Tuple* tuple, size_t index, String** outValue) {
    return generic_getter(tuple, TUPLE_TYPE_STRING, index, (void**)outValue);
}
