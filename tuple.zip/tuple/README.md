



## Example 1 : create tuple and fill it with 3 different type 

```c
#include "tuple/tuple.h"
#include <stdio.h>

int main() {
    Tuple* myTuple = tuple_create(3, TUPLE_TYPE_INT, TUPLE_TYPE_FLOAT, TUPLE_TYPE_CHAR); // Create a tuple with 3 elements
    int intValue = 42;
    float floatValue = 3.14f;
    char charValue = 'A';

    tuple_set_int(myTuple, 0, intValue);
    tuple_set_float(myTuple, 1, floatValue);
    tuple_set_char(myTuple, 2, charValue);

    // Get and print values
    int retrievedInt;
    float retrievedFloat;
    char retrievedChar;

    if (tuple_get_int(myTuple, 0, &retrievedInt)) {
        printf("Int value: %d\n", retrievedInt);
    } 
    else {
        printf("Failed to retrieve int value.\n");
    }

    if (tuple_get_float(myTuple, 1, &retrievedFloat)) {
        printf("Float value: %f\n", retrievedFloat);
    } 
    else {
        printf("Failed to retrieve float value.\n");
    }

    if (tuple_get_char(myTuple, 2, &retrievedChar)) {
        printf("Char value: %c\n", retrievedChar);
    } 
    else {
        printf("Failed to retrieve char value.\n");
    }

    tuple_deallocate(myTuple);
    return 0;
}
```

## Example 2 : how to use char* and double in tuple 

```c
#include "tuple/tuple.h"
#include <stdio.h>

int main() {
    // Create a tuple with 2 elements
    Tuple* myTuple = tuple_create(2, TUPLE_TYPE_CHAR_STRING, TUPLE_TYPE_DOUBLE);
    const char* myString = "Hello, World!";
    double myDouble = 3.14;
    
    tuple_set_double(myTuple, 0, myDouble);
    tuple_set_char_string(myTuple, 1, myString);

    // Retrieve and print the double value
    double retrievedDouble;
    if (tuple_get_double(myTuple, 0, &retrievedDouble)) {
        printf("Double element: %f\n", retrievedDouble);
    } 
    else {
        printf("Failed to retrieve double element.\n");
    }

    // Retrieve and print the char string value
    char* retrievedString;
    if (tuple_get_char_string(myTuple, 1, &retrievedString)) {
        printf("String element: %s\n", retrievedString);
    } 
    else {
        printf("Failed to retrieve string element.\n");
    }

    tuple_deallocate(myTuple);
    return 0;
}
```

## Example 3 : Use Vector object 

```c
#include "tuple/tuple.h"
#include <stdio.h>

int main() {
    Tuple* myTuple = tuple_create(4, TUPLE_TYPE_INT, TUPLE_TYPE_FLOAT, TUPLE_TYPE_CHAR, TUPLE_TYPE_VECTOR);

    int intValue = 42;
    tuple_set_int(myTuple, 0, intValue);

    float floatValue = 3.14f;
    tuple_set_float(myTuple, 1, floatValue);

    char charValue = 'A';
    tuple_set_char(myTuple, 2, charValue);

    // Create a vector and set it in the tuple
    Vector* vectorValue = vector_create(sizeof(int));
    int vectorData = 100;
    vector_push_back(vectorValue, &vectorData);
    tuple_set_vector(myTuple, 3, vectorValue);

    int retrievedInt;
    float retrievedFloat;
    char retrievedChar;
    Vector* retrievedVector;

    if (tuple_get_int(myTuple, 0, &retrievedInt)) {
        printf("Int element: %d\n", retrievedInt);
    }

    if (tuple_get_float(myTuple, 1, &retrievedFloat)) {
        printf("Float element: %f\n", retrievedFloat);
    }

    if (tuple_get_char(myTuple, 2, &retrievedChar)) {
        printf("Char element: %c\n", retrievedChar);
    }

    if (tuple_get_vector(myTuple, 3, &retrievedVector)) {
        // Check if the vector is not empty
        if (vector_size(retrievedVector) > 0) {
            int* item = (int*)vector_at(retrievedVector, 0);
            if (item) {
                printf("Vector element: %d\n", *item);
            } else {
                printf("Vector element is NULL\n");
            }
        } 
    } 

    vector_deallocate(vectorValue);
    tuple_deallocate(myTuple);
    return 0;
}
```

## Example 4 : String object 

```c
#include "tuple/tuple.h"
#include <stdio.h>

int main() {
    Tuple* myTuple = tuple_create(4, TUPLE_TYPE_INT, TUPLE_TYPE_FLOAT, TUPLE_TYPE_STRING);

    int intValue = 42;
    tuple_set_int(myTuple, 0, intValue);

    float floatValue = 3.14f;
    tuple_set_float(myTuple, 1, floatValue);

    String* str = string_create("Hello My String Object");
    tuple_set_string(myTuple, 2, str);

    int retrievedInt;
    float retrievedFloat;
    String* retrievedString;

    if (tuple_get_int(myTuple, 0, &retrievedInt)) {
        printf("Int element: %d\n", retrievedInt);
    }
    if (tuple_get_float(myTuple, 1, &retrievedFloat)) {
        printf("Float element: %f\n", retrievedFloat);
    }
    if (tuple_get_string(myTuple, 2, &retrievedString)) {
        printf("String element : %s", string_c_str(retrievedString)); 
    } 

    string_deallocate(str);
    tuple_deallocate(myTuple);
    return 0;
}
```